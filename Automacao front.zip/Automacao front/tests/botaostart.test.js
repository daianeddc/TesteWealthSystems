module.exports = {
    'Botao start': function(browser){
             browser
                 .url('https://the-internet.herokuapp.com/dynamic_loading/1')
                 .waitForElementVisible('div#start', 3000)
                 .click('div button')
                 .waitForElementVisible('div#finish h4', 5000)
                 .assert.containsText('div#finish h4', 'Hello World!')
                 .end();
                 
    }       
}
