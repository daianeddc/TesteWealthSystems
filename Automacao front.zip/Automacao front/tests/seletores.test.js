module.exports = {
'seletores': function(browser){
    browser
        .url('https://the-internet.herokuapp.com/challenging_dom')
        .waitForElementVisible('.button', 3000)
        .click('a:first-child.button')
        .click('.button.alert')
        .click('.button.success')
        .click('tbody tr:nth-child(1) a[href="#edit"]')
        .click('tbody tr:nth-child(1) a[href="#delete"]')
        .click('tbody tr:nth-child(2) a[href="#edit"]')
        .click('tbody tr:nth-child(2) a[href="#delete"]')
        .click('tbody tr:nth-child(3) a[href="#edit"]')
        .click('tbody tr:nth-child(3) a[href="#delete"]')
        .click('tbody tr:nth-child(4) a[href="#edit"]')
        .click('tbody tr:nth-child(4) a[href="#delete"]')
        .click('tbody tr:nth-child(5) a[href="#edit"]')
        .click('tbody tr:nth-child(5) a[href="#delete"]')
        .click('tbody tr:nth-child(6) a[href="#edit"]')
        .click('tbody tr:nth-child(6) a[href="#delete"]')
        .click('tbody tr:nth-child(7) a[href="#edit"]')
        .click('tbody tr:nth-child(7) a[href="#delete"]')
        .click('tbody tr:nth-child(8) a[href="#edit"]')
        .click('tbody tr:nth-child(8) a[href="#delete"]')
        .click('tbody tr:nth-child(9) a[href="#edit"]')
        .click('tbody tr:nth-child(9) a[href="#delete"]')
        .click('tbody tr:nth-child(10) a[href="#edit"]')
        .click('tbody tr:nth-child(10) a[href="#delete"]')
        .end();
}
}